const { SlashCommandBuilder } = require("discord.js");
const sql = require("../../lib/mysql");

module.exports = {
  name: "stats",
  data: new SlashCommandBuilder()
    .setName("stats")
    .setDescription("See other player's stats or your own!")
    .addStringOption((option) => {
      option
        .setName("player")
        .setDescription("Get the Information about a Player")
        .setRequired(true);
      return option;
    }),

  async execute(interaction, client) {
    const sent = await interaction.reply({
      content: "<a:loading:1069476742571511860> Loading...",
      fetchReply: true,
    });
    const result = sql.execute(
      `SELECT * FROM Player WHERE username = \'testplayer\'`
    );
    if (!result) {
      console.log(result);
      return interaction.editReply({
        content: "Player not found",
      });
    }

    let statsEmbed = {
      description: `Here is **${result.username}**'s stats.`,
      fields: [
        {
          name: `Player Level`,
          value: `**${result.level}**`,
          inline: true,
        },
        {
          name: `Player XP`,
          value: `**Null**`,
          inline: true,
        },
      ],
      footer: {
        text: `Query took ${
          sent.createdTimestamp - interaction.createdTimestamp
        }ms.`,
      },
      color: client.color.blue,
    };
    interaction.editReply({ content: "", embeds: [statsEmbed] });
  },
};
