// Event listener for any unhandled errors
client.on("error", (error) => {
  console.error("Unhandled error:", error);
});

// Event listener for any unhandled promise rejections
process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled promise rejection:", reason);
});
  
// Event listener for any uncaught exceptions
process.on("uncaughtException", (error) => {
  console.error("Uncaught exception:", error);
});

// Event listener for when the bot is disconnected
client.on("disconnect", () => {
  console.warn("Disconnected from Discord");
});

// Event listener for when the bot is attempting to reconnect
client.on("reconnecting", () => {
  console.warn("Attempting to reconnect to Discord...");
});

// Event listener for when the bot reconnects successfully
client.on("resume", (replayed) => {
  console.log(`Reconnected to Discord (replayed ${replayed} events)`);
});
