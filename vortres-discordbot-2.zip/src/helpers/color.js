// '0x' is basically the same as '#'
// so please remove the '#' in your hex color
module.exports = {
  invis: 0x2f3136,
  blue: 0x2045db,
  red: 0xf01831,
  yellow: 0xffff64,
};
